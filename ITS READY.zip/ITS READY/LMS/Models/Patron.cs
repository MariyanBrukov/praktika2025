﻿using System.ComponentModel.DataAnnotations;

namespace LMS.Models
{
    public class Patron
    {
        public int PatronId { get; set; }

        [Required]
        public string FirstName { get; set; } = "";

        [Required]
        public string MiddleName { get; set; } = "";

        [Required]
        public string LastName { get; set; } = "";

        [Required, EmailAddress]
        public string Email { get; set; } = "";

        [Phone]
        public string Phone { get; set; } = "";
    }
}
