﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LMS.Models
{
    public class Library
    {
        public int LibraryId { get; set; }

        [Required]
        public string Name { get; set; } = "";

        [Required]
        public string Location { get; set; } = "";

        public List<Book> Books { get; set; } = new List<Book>();
    }
}
