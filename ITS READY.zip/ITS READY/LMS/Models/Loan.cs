﻿using System.ComponentModel.DataAnnotations;

namespace LMS.Models
{
    public class Loan
    {
        public int LoanId { get; set; }

        [Required]
        public string ISBN { get; set; } = "";

        [Required]
        public int PatronId { get; set; }

        [Required]
        public DateTime LoanDate { get; set; }

        [Required]
        public DateTime DueDate { get; set; }

        public Book? Book { get; set; }
        public Patron? Patron { get; set; }
    }
}
