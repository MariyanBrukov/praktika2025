﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data;

public class ApplicationDbContext : IdentityDbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

public DbSet<LibraryManagementSystem.Models.Book> Book { get; set; } = default!;

public DbSet<LibraryManagementSystem.Models.Patron> Patron { get; set; } = default!;

public DbSet<LibraryManagementSystem.Models.Loan> Loan { get; set; } = default!;

public DbSet<LibraryManagementSystem.Models.Library> Library { get; set; } = default!;
}
