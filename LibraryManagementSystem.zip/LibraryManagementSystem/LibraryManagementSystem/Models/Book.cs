﻿using Microsoft.Extensions.DependencyModel;
using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class Book
    {
        public int BookId { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Author { get; set; }

        [Required]
        public string ISBN { get; set; }

        public int PublishedYear { get; set; }

        public string Status { get; set; } = "Available";

        public int LibraryId { get; set; }
        public Library Library { get; set; }
    }
}
