﻿using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class Loan
    {
        public int LoanId { get; set; }

        public int BookId { get; set; }
        public Book Book { get; set; }

        public int PatronId { get; set; }
        public Patron Patron { get; set; }

        public DateTime LoanDate { get; set; } = DateTime.Now;

        [Required]
        public DateTime DueDate { get; set; }
    }
}
