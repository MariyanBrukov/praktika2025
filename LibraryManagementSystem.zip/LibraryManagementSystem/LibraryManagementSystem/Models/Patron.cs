﻿using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class Patron
    {
        public int PatronId { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        public DateTime AccountCreated { get; set; } = DateTime.Now;

        public ICollection<Loan> Loans { get; set; }
    }
}
